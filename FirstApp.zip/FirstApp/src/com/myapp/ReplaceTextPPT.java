package com.myapp;

import java.awt.Event;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hpsf.PropertySetFactory;
import org.apache.poi.hpsf.SummaryInformation;
import org.apache.poi.hslf.usermodel.HSLFConnectorShape;
import org.apache.poi.hslf.usermodel.HSLFPictureData;
import org.apache.poi.hslf.usermodel.HSLFPictureShape;
import org.apache.poi.hslf.usermodel.HSLFShape;
import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hslf.usermodel.HSLFSlideShowImpl;
import org.apache.poi.hslf.usermodel.HSLFTextShape;
import org.apache.poi.sl.usermodel.PictureData.PictureType;
import org.apache.poi.sl.usermodel.PlaceableShape;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFConnectorShape;
import org.apache.poi.xslf.usermodel.XSLFPictureData;
import org.apache.poi.xslf.usermodel.XSLFPictureShape;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.apache.poi.xslf.usermodel.XSLFPictureData;



public class ReplaceTextPPT {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		
	      File file = new File("Javatpoint.pptx");
//	      XMLSlideShow ppt = new XMLSlideShow(new FileInputStream(file));	
	      HSLFSlideShow ppt = new HSLFSlideShow(new HSLFSlideShowImpl("Javatpoint.ppt"));



	      
	      //getting the shapes in the presentation
	      System.out.println("Shapes in the presentation:");
	      for (HSLFSlide slide : ppt.getSlides()) {
	         for (HSLFShape sh : slide.getShapes()) {
	             // name of the shape
	             String name = sh.getShapeName();
	             
	             // shapes's anchor which defines the position of this shape in the slide
	             /*if (sh instanceof PlaceableShape) {
	                 java.awt.geom.Rectangle2D anchor = ((PlaceableShape)sh).getAnchor();
	                 System.out.println(name);
	             }*/
	             if (sh instanceof HSLFConnectorShape) {
	                 HSLFConnectorShape line = (HSLFConnectorShape) sh;	                 
	             } else if (sh instanceof HSLFTextShape) {
	            	 HSLFTextShape shape = (HSLFTextShape) sh;
	                 if (shape.getShapeName().contains("Rectangle")) {
	                	 System.out.println(name);
	                	 int x = 0, y = 0, width = 0, height = 0;
	                	 x = (int) shape.getAnchor().getX();
	                	 y = (int) shape.getAnchor().getY();
	                	 width = (int) shape.getAnchor().getWidth();
	                	 height = (int) shape.getAnchor().getHeight();
	                	 boolean ok = slide.removeShape(shape);
	                	 if (ok) {
	                	        // the shape was removed. Do something.
	                	 }
	                	 byte[] pictureData = IOUtils.toByteArray(new FileInputStream("female.jpg"));
	                	 
	                	// add a new picture to this slideshow and insert it in a new slide
	                	 //HSLFPictureData pd1 = ppt.addPicture(new File("JavaCollection.png"), PictureType.PNG);
	                	 HSLFPictureData pd1 = ppt.addPicture(pictureData, PictureType.JPEG);
	                	 HSLFPictureShape pictNew = new HSLFPictureShape(pd1);
	                	 // set image position in the slide
	                	 pictNew.setAnchor(new java.awt.Rectangle(x, y, width, height));
	                	 //HSLFSlide slide1 = ppt.createSlide();
	                	 slide.addShape(pictNew);
	                 }
	             } else if (sh instanceof HSLFPictureShape) {
	                 HSLFPictureShape shape = (HSLFPictureShape) sh;
	                 System.out.println(name);
	             } else {
	            	 System.out.println(name);
	             }
	         }
	      }
	      SummaryInformation si = new SummaryInformation();
	     String title = si.getTitle();
	     String Author= si.getLastAuthor();
	     System.out.println("Title:"+title+"\n Author"+Author);
	      FileOutputStream out = new FileOutputStream("Javatpoint3.ppt");
	      ppt.write(out);
	      out.close();
	}
}
